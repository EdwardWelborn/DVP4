Readme file for MyGameLib

Does the application compile? Yes
Is the application functional? Yes, incomplete but functional
Does the application UI seem complete? yes
Did you complete all of your required features? no, a few are not finished
Do the proposed functions operate completely? yes
Are there any placeholders in the UI? no
Are there any icons or links that do not function? no
Are there any bugs in the application? none

Installation instructions
Hardware requirements - I tested on iphone 7, and 8
Log in requirements/credentials for testing - email: test@test.com pw: Tester@2021
Known bugs
Any other special requirements your instructor should know about: the application is not 100% but you can see the reads from the firebase database and logins
A collection of all your time logs for the entire month (you may include submissions from previous weeks, but assemble them into one document.
Push your final project folder to your remote Git repo : DONE